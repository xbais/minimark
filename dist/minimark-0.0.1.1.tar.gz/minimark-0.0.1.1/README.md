# MiniMark : The CLI Markdown Editor / Viewer
